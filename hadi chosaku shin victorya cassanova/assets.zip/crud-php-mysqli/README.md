# Aplikasi CRUD dengan PHP dan MySQLi (Procedural Style)
Bahasa Pemrograman 	: PHP,
Database		        : MySQL (Ekstensi MySQLi),
Metode Pemrograman	: Prosedural,
Template		        : Bootstrap 3

# Fitur
1. Create
2. Read
3. Update
4. Delete
5. Search
6. Pagination
7. Penggunaan CSS Bootstrap 3
8. Membuat fungsi untuk membatasi karakter yang diinputkan
9. Keamanan dasar untuk mencegah sql injection
